const keys = ['name', 'age'];
const values = ['John', 30];

const resultObj = Object.fromEntries([keys,values])
console.log(resultObj)